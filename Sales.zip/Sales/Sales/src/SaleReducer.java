import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;
	
	public class SaleReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

		private 	Logger logger = Logger.getLogger(SaleReducer.class);
	   public void reduce(Text key, Iterable<IntWritable> values, Context context)
	      throws IOException, InterruptedException {
		    
		//  Text key = t_key;
			int frequencyForCountry = 0;
			
			for(IntWritable value:values) {
				// replace type of value with the actual type of our value
				int freq = value.get();
				frequencyForCountry += freq;
				
			}
			
			
		context.write(key, new IntWritable(frequencyForCountry));
}
	}