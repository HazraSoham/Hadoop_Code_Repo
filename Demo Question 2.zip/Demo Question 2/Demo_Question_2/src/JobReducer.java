import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
 

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;
	
	public class JobReducer extends Reducer<Text, Text, NullWritable,Text>
	{

		//	String[] stringArr=new String[3];
		

		private 	Logger logger = Logger.getLogger(JobReducer.class);
	 
	    private Text cityKey = new Text();
	    private IntWritable result = new IntWritable();
	
	    
	 	   HashMap<String,String> map 
           = new HashMap<String,String>(); 
      
	    
	    @Override 
	   
	    protected void setup(Context context) throws IOException, InterruptedException { 
	      // That's where file stored in distributed cache is used 
	    	
	    		
	    		context.write(NullWritable.get(),new Text("IOU,Location,A1,A2,A3,A4"));
	    		
	    	
	    	BufferedReader in = new BufferedReader(new FileReader("portalcache.txt"));
			String str;

			while((str = in.readLine()) != null){
				
             	String[] ch=str.split(",");

             	logger.info("Output of cache values");
             	
             	logger.info(ch[0]);
             	
             	logger.info(ch[1]);
             	
               	map.put(ch[0],ch[1]); 
			}
			for (Map.Entry<String,String> entry : map.entrySet())  
		           logger.info("Key = " + entry.getKey() + 
		                             ", Value = " + entry.getValue());			
			
    }
	   public void reduce(Text keys, Iterable<Text> values, Context context)
	      throws IOException, InterruptedException {
              String keyString = keys.toString();   
	   logger.info(keyString);
	   
	   
	   
	   String valueString = values.toString();   
	   
	   logger.info(valueString);
	 
	   String[] recordvalue = valueString.split(",");
   
	   int totala1=0;
	   int totala2=0;
	   int totala3=0;
	   int totala4=0;
	  
	   
	   String iou=new String();
	 logger.info("welcome to logger");

String role=new String();
String location=new String();
for(Text value:values)


	    	{
		 logger.info(value);
		 String record=value.toString();
		 String[] avalue = record.split(",");
		 
		 //chasnge in key string 
		 logger.info("this is the key to compare"+avalue[7]);
	
		
		 
		 if(map.containsKey(avalue[7]))
			{
			
		location=map.get(avalue[7]);
			
			}	
		 
		 logger.info("this is location"+location);

		 role=avalue[6];
		 
		 
      if(role.equalsIgnoreCase("A1"))
      {
     	 totala1++;
     	 logger.info(totala1);
     	 
      }
      
      if(role.equalsIgnoreCase("A2"))
      {
     	 totala2++;
     	 logger.info(totala2);
     	 
      }
      
      if(role.equalsIgnoreCase("A3"))
      {
     	 totala3++;
     	 logger.info(totala3);
     	 
      }
      
      if(role.equalsIgnoreCase("A4"))
      {
     	 totala4++;
     	 logger.info(totala4);
     	 
      }
         logger.info(totala1);
         
         logger.info(totala2);  
         
logger.info(totala3);
         
         logger.info(totala4);  
         
         iou=avalue[2];
         
         
         logger.info(avalue[2]);
	    	}
	



		   logger.info("this is my reducer ");

		 
		   String outRec=iou+","+ location+","+totala1+","+totala2+","+totala3+","+totala4;
			  
		   logger.info(outRec);
  
	        context.write(NullWritable.get(),new Text(outRec));
	    
	    }
	}