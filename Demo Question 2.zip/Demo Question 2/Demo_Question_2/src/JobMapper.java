import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.util.*;
import java.io.*;
import java.net.URI;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;

public class JobMapper extends Mapper<LongWritable, Text, Text,Text> {

	private 	Logger logger = Logger.getLogger(JobMapper.class);


	private final static IntWritable one = new IntWritable(1);
	
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

				
			String healthStatus=new String();
			String skey= new String();
			String valueString = value.toString();
			String[] record = valueString.split(",");
			String comment="";
	 

			
			
		
 
		
			logger.info(valueString);
			logger.info("Number of elements" + record.length);
		if(record.length==9)
	
		{
		
			  comment=record[8];
				
				 logger.info(comment);
					
				 if(comment.contains("Not"))
				 {
					 healthStatus="Yes";
					 
					
					 
				 }
				 
				 else
				 {

					 healthStatus="No";
					  
					 
				 }

			
				 skey=record[2]+"_"+record[7];
				 
				 
				 logger.info(skey);
					
			 
				 
				 logger.info("healthStatus is"+healthStatus);
					
				  
                                 String srecord =valueString + ","+healthStatus;
                                 
				 logger.info("mapper out "+skey+ " ::"+srecord );
				 
          		context.write(new Text(skey),new Text(srecord));
          		
      	}
			}

		}

      