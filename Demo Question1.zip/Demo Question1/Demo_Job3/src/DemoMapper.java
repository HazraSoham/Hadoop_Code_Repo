import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.util.*;
import java.io.*;
import java.net.URI;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;

public class DemoMapper extends Mapper<LongWritable, Text, Text,Text> {

	private 	Logger logger = Logger.getLogger(DemoMapper.class);


	private final static IntWritable one = new IntWritable(1);
	
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

			
			String valueString = value.toString();
			
			logger.info(valueString);
			
			String[] record = valueString.split(",");
			
			int rlength=record.length;

			logger.info(rlength);
			
		
			String rkey;
			
			String health=new String();
			
			String svalue=new String();
			
			String skey= new String();
			
		if(rlength==9)
			{
				
				 String comment=record[8];
				
				 logger.info(comment);
					
				 if(comment.contains("Not"))
				 {
					 health="Yes";
					 
					 logger.info(health);
					 
				 }
				 
				 else
				 {

					 health="No";
					 logger.info(health);
					 
				 }
				 
				 skey=record[2];
				 
				 
				 logger.info(skey);
					
				 logger.info("mapper key is "+skey);
				 
				 
				 logger.info("health is"+health);
					
				 
				 svalue=valueString+","+health;
				 
				 logger.info("mapper value is "+svalue);
				 
          		context.write(new Text(skey),new Text(svalue));
 
			
			}
			}

		}

      