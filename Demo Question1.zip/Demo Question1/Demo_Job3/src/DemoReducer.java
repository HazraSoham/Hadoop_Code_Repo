import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;
import java.lang.*;	
	public class DemoReducer extends Reducer<Text,Text, NullWritable, Text> {

		private 	Logger logger = Logger.getLogger(DemoReducer.class);
		
		protected void setup(Context context) throws IOException, InterruptedException { 
			
		
		context.write(NullWritable.get(),new Text("IOU,GoodCount,BadCount,Location"));
		
		}
		
		
	   public void reduce(Text key, Iterable<Text> values, Context context)
	      throws IOException, InterruptedException {

		   
		   String keyString = key.toString();   
		   logger.info(keyString);
		   
		   String valueString = values.toString();   
		   
		   logger.info(valueString);
		   
		   
		   String[] recordvalue = valueString.split(",");
		   
		   int healthy=0;
		   int unhealthy=0;
		  
		 logger.info("welcome to reducer");
		 
String loca=new String();
		 for(Text value:values)
		   
		   {
			 
			 logger.info(value);
			 String record=value.toString();
			 String[] avalue = record.split(","); 
			
			
			 logger.info(avalue[9]);
			
			 if(avalue[9].equalsIgnoreCase("Yes"))
			 {
				 healthy++;
			 }
			 
			 else
			 
			 {
				 unhealthy++;
           
			 }
			
			 logger.info(healthy);
			
			logger.info(unhealthy);
			 
			
			loca=avalue[7];
		   }
			logger.info("final"+healthy);
			logger.info("final"+unhealthy);	
		   
			logger.info(keyString);
		   
	   String s=keyString+","+healthy+","+unhealthy+loca;
	   logger.info(s);
	   context.write(NullWritable.get(),new Text(s));
	   
	   }
	}
