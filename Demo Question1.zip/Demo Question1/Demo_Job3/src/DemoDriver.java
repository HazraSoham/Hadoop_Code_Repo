import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.log4j.Logger;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;




 public class DemoDriver {
		   
		  public static void main(String[] args) throws Exception {

		    /*
		     * Validate that two arguments were passed from the command line.
		     */
			  Logger logger = Logger.getLogger(DemoDriver.class);

		     Configuration conf = new Configuration();
		    /*
		     * Instantiate a Job object for your job's configuration. 
		     */
		    Job job = new Job();
		    
		    /*
		     * Specify the jar file that contains your driver, mapper, and reducer.
		     * Hadoop will transfer this jar file to nodes in your cluster running 
		     * mapper and reducer tasks.
		     */
		    job.setJarByClass(DemoDriver.class);
		    
		    /*
		     * Specify an easily-decipherable name for the job.
		     * This job name will appear in reports and logs.
		     */
		    job.setJobName("webDriver");

		    job.setMapperClass(DemoMapper.class);
		     job.setReducerClass(DemoReducer.class);
		    job.setOutputKeyClass(Text.class);
		    job.setOutputValueClass(Text.class);
		    job.setInputFormatClass(TextInputFormat.class);
		    job.setOutputFormatClass(TextOutputFormat.class);
		    Path outputPath = new Path(args[1]);
		    //Configuring the input/output path from the filesystem into the job
		    FileInputFormat.addInputPath(job, new Path(args[0]));
		    FileOutputFormat.setOutputPath(job, new Path(args[1]));
		    //deleting the output path automatically from hdfs so that we don't have to delete it explicitly
		    outputPath.getFileSystem(conf).delete(outputPath);
		    //exiting the job only if the flag value becomes false
		    try { 
		    	  
		        // the complete URI(Uniform Resource  
		        // Identifier) file path in Hdfs 
		     //    <value></value>

		     

		    } 
		    catch (Exception e) { 
		    	logger.info(" ");

		    	System.out.println("File Not Added"); 
		        System.exit(1); 
		    } 
		    

		    
		    boolean success = job.waitForCompletion(true);
		    System.exit(success ? 0 : 1);
		  }
 }
 

