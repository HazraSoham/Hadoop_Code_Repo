import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;

public class WCReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

	private Logger logger = Logger.getLogger(WCReducer.class);
 

	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {

	     int sum =0;
		String fileKey = key.toString();
		// District,score,date
		logger.info("Reducer:- key " + key);
		 for (IntWritable x : values) {
			// logger.info("Reducer:- Error " + x.toString());
			//logger.info("Reducer:- values " + x.toString());

 	      sum = sum +x.get();
		}
		
		 context.write(key, new IntWritable(sum));
		logger.info("Reducer:- end ");

	}
 

}