import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.util.*;
import java.io.*;
import java.net.URI;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;

public class DCMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

	private 	Logger logger = Logger.getLogger(DCMapper.class);

	  private final static IntWritable one = new IntWritable(1);
	  private Text item = new Text();
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			logger.info("this is my ");
			String[] stringArr = value.toString().split(",");
		      item.set(stringArr[0] + " " + stringArr[2]);             
                  logger.info(" these are items "+item);
		      
		      Integer sales = Integer.parseInt(stringArr[1]);
		      logger.info(" these are sales "+sales);
		      context.write(item, new IntWritable(sales));	         
		      
		      logger.info("this is my mapper ");
			}
}
		
			
		
	


