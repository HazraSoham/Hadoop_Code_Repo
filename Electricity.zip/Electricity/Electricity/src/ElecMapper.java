
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.util.*;
import java.io.*;
import java.net.URI;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.log4j.Logger;

public class ElecMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
 

	 
	private 	Logger logger = Logger.getLogger(ElecMapper.class);

	  private final static IntWritable one = new IntWritable(1);
	  private Text word = new Text();
	   
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

			String line = value.toString(); 
	         String lasttoken = null; 
//	         StringTokenizer s = new StringTokenizer(line,"\t"); 
//	         StringTokenizer s = new StringTokenizer(line,","); 

	         String[] s=line.split(",");
	         
	         
	         logger.info("last token" + line);
	         //String year = s.nextToken(); 
	         
	            lasttoken = s[2];

	           String year=s[0];
	           Thread.sleep(5000);
	           logger.info("what is the year" + year);
		         
	           logger.info("last token" + lasttoken);
	        //try with index
	         int avgprice = Integer.parseInt(lasttoken); 
	         logger.info(" the year and price info" + year+" "+ avgprice);
	         context.write(new Text(year), new IntWritable(avgprice)); 		        }
	        	 
	         
	           //value.set(token);
			}

		
			
		
	


