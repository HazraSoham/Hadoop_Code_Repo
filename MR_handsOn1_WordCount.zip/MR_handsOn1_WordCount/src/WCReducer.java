import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.log4j.Logger;

public class WCReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

	private Logger logger = Logger.getLogger(WCReducer.class);
 

	@Override
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {

	     int sum =0;
		String fileKey = key.toString();
 
		logger.info("Reducer:- key " + key);
		 for (IntWritable x : values) {
		 

 	      sum = sum +x.get();
		}
		
		 context.write(key, new IntWritable(sum));
		 
		 // please add the delay accordingly to view log files in hue.
		 Thread.sleep(1000);
		 
		logger.info("Reducer:- end ");

	}
 

}